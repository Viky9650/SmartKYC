import { useState, useEffect, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { casesApi } from '../services/api'
import {
  PageTopbar, RiskRing, StatusBadge, FlagTags, EmptyState, SectionHeader,
} from '../components/shared/UI'
import {
  InvestigationPlanCard, AgentTimeline, VerificationSourcesPanel,
  AgentFindingsPanel, LiveLog,
} from '../components/investigation/InvestigationView'
import DocumentExtractionPanel from '../components/documents/DocumentExtractionPanel'
import DocumentUpload from '../components/documents/DocumentUpload'
import { formatDateTime } from '../utils'
import type { CaseDetail } from '../types'

export default function CaseDetailPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const [detail, setDetail] = useState<CaseDetail | null>(null)
  const [loading, setLoading] = useState(true)
  const [polling, setPolling] = useState(false)

  const fetchDetail = useCallback(async () => {
    if (!id) return
    try {
      const data = await casesApi.get(id)
      setDetail(data)
      // Keep polling if still investigating
      if (['pending', 'investigating'].includes(data.case.status)) {
        setPolling(true)
      } else {
        setPolling(false)
      }
    } catch {
      setPolling(false)
    } finally {
      setLoading(false)
    }
  }, [id])

  useEffect(() => {
    fetchDetail()
  }, [fetchDetail])

  useEffect(() => {
    if (!polling) return
    const interval = setInterval(fetchDetail, 3000)
    return () => clearInterval(interval)
  }, [polling, fetchDetail])

  if (loading) {
    return (
      <div>
        <PageTopbar title="Case Detail" />
        <div style={{ padding: 24, textAlign: 'center', color: '#96a3bb' }}>Loading...</div>
      </div>
    )
  }

  if (!detail) {
    return (
      <div>
        <PageTopbar title="Case Not Found" />
        <div style={{ padding: 24 }}>
          <EmptyState icon="❓" title="Case not found" sub="The case may have been deleted or the ID is invalid" />
        </div>
      </div>
    )
  }

  const { case: c, agents, verification_sources, documents, events, reviews } = detail
  const isInvestigating = ['pending', 'investigating'].includes(c.status)
  const latestReview = reviews?.[0]

  return (
    <div>
      <PageTopbar
        title={c.subject_name}
        sub={`${c.case_number} · ${c.subject_type || 'Individual'} · ${c.nationality || '—'}`}
        actions={
          <>
            {polling && <span className="badge badge-blue" style={{ animation: 'pulse 2s infinite' }}>● Investigating</span>}
            <StatusBadge status={c.status} />
            {c.status === 'review' && (
              <button className="btn btn-primary" onClick={() => navigate('/review')}>
                Review Queue →
              </button>
            )}
          </>
        }
      />

      <div style={{ padding: 24 }}>

        {/* Summary Row */}
        {(() => {
          // While investigating, show the highest agent score seen so far
          // so the gauge updates live instead of staying at 0
          const liveScore = isInvestigating && c.risk_score === 0 && agents?.length > 0
            ? Math.max(...agents.map(a => a.risk_score || 0))
            : c.risk_score
          return (
        <div style={{ display: 'grid', gridTemplateColumns: 'auto 1fr auto', gap: 20, marginBottom: 20, alignItems: 'start' }}>
          {/* Risk gauge */}
          <div className="card" style={{ minWidth: 180, textAlign: 'center' }}>
            <span className="card-title">
              Risk Score
              {isInvestigating && <span style={{ fontSize: 10, color: '#4a7fe8', marginLeft: 6 }}>live</span>}
            </span>
            <RiskRing score={liveScore} />
            {isInvestigating && liveScore > 0 && liveScore !== c.risk_score && (
              <div style={{ fontSize: 10, color: '#96a3bb', marginTop: 4 }}>
                highest agent so far
              </div>
            )}
          </div>

          {/* Subject info */}
          <div className="card">
            <span className="card-title">Subject Profile</span>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px 20px', fontSize: 13 }}>
              {[
                ['Subject Type',   c.subject_type  || '—'],
                ['Nationality',    c.nationality   || '—'],
                ['Date of Birth',  c.date_of_birth || '—'],
                ['Case Number',    c.case_number],
                ['Status',         c.status],
                ['Created',        formatDateTime(c.created_at)],
              ].map(([label, value]) => (
                <div key={label}>
                  <div style={{ fontSize: 10, color: '#96a3bb', fontFamily: 'JetBrains Mono, monospace', textTransform: 'uppercase', marginBottom: 1 }}>{label}</div>
                  <div style={{ color: '#1e2a3a', fontFamily: 'JetBrains Mono, monospace', fontSize: 12 }}>{String(value)}</div>
                </div>
              ))}
            </div>
            {c.notes && (
              <div style={{ marginTop: 12, padding: '8px 10px', background: '#eef1f8', borderRadius: 6, fontSize: 12, color: '#5a6a84', fontStyle: 'italic' }}>
                {c.notes}
              </div>
            )}
          </div>

          {/* Flags + Review status */}
          <div style={{ minWidth: 220 }}>
            <div className="card" style={{ marginBottom: 10 }}>
              <span className="card-title">Risk Flags</span>
              {agents?.flatMap(a => a.flags || []).length > 0 ? (
                <FlagTags flags={[...new Set(agents.flatMap(a => a.flags || []))]} />
              ) : (
                <span style={{ fontSize: 12, color: '#96a3bb', fontStyle: 'italic' }}>No flags</span>
              )}
            </div>

            {latestReview && (
              <div className="card">
                <span className="card-title">Last Review</span>
                <div style={{ fontSize: 12, color: '#5a6a84', marginBottom: 6 }}>
                  {latestReview.reviewer_name} · {formatDateTime(latestReview.reviewed_at)}
                </div>
                <span className={`badge ${
                  latestReview.decision === 'approved' ? 'badge-green' :
                  latestReview.decision === 'rejected' ? 'badge-red' : 'badge-amber'
                }`}>
                  {latestReview.decision.replace(/_/g, ' ').toUpperCase()}
                </span>
                {latestReview.comments && (
                  <div style={{ marginTop: 8, fontSize: 11, color: '#5a6a84', fontStyle: 'italic' }}>
                    "{latestReview.comments}"
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
          )
        })()}

        {/* Investigation Plan */}
        <div style={{ marginBottom: 16 }}>
          <InvestigationPlanCard
            plan={c.investigation_plan as any}
            loading={isInvestigating && !c.investigation_plan}
          />
        </div>

        {/* Document Extraction — prominent section */}
        <div className="card" style={{ marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <SectionHeader
              title="Document Extraction Results"
              badge={<span className="badge badge-green">{documents?.length || 0} doc(s)</span>}
            />
          </div>
          {documents?.length > 0 ? (
            <DocumentExtractionPanel documents={documents} />
          ) : (
            <div style={{
              padding: '20px', textAlign: 'center',
              border: '2px dashed #d1d9ee', borderRadius: 10,
              background: '#f8f9fd', marginBottom: 16,
            }}>
              <div style={{ fontSize: 28, marginBottom: 8, opacity: 0.4 }}>📄</div>
              <div style={{ fontSize: 13, fontWeight: 500, color: '#5a6a84', marginBottom: 4 }}>No documents uploaded yet</div>
              <div style={{ fontSize: 12, color: '#96a3bb' }}>Upload an ID document to extract fields</div>
            </div>
          )}
          {/* Attach additional document */}
          <div style={{ borderTop: '1px solid #e4e9f4', paddingTop: 14, marginTop: 4 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: '#1e2a3a', marginBottom: 10 }}>
              {documents?.length ? 'Attach Another Document' : 'Upload Identity Document'}
            </div>
            <DocumentUpload caseId={c.id} onUploaded={() => fetchDetail()} />
          </div>
        </div>

        {/* Two column: agents + verification */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
          <AgentTimeline agents={agents || []} loading={isInvestigating} plan={c.investigation_plan as any} />
          <VerificationSourcesPanel sources={verification_sources || []} />
        </div>

        {/* Two column: findings + log */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
          <AgentFindingsPanel agents={agents || []} />
          <LiveLog events={events || []} />
        </div>

        {/* Route to review CTA */}
        {c.status === 'review' && (
          <div className="card" style={{ border: '1px solid #fde68a', background: '#fef9c322' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontSize: 15, fontWeight: 600, color: '#1e2a3a', marginBottom: 4 }}>
                  Investigation Complete — Pending Human Review
                </div>
                <div style={{ fontSize: 12, color: '#5a6a84' }}>
                  Risk score: <span style={{ color: '#f59e0b', fontFamily: 'JetBrains Mono, monospace', fontWeight: 700 }}>{Math.round(c.risk_score)}</span>
                  {' '}· {(agents || []).length} agents completed
                </div>
              </div>
              <button
                className="btn btn-primary"
                style={{ padding: '10px 20px' }}
                onClick={() => navigate('/review')}
              >
                Open Review Queue →
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
